package com.dzx.tangzhuan.util;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.view.ViewCompat;
import android.view.View;
import android.view.animation.CycleInterpolator;
import android.view.animation.TranslateAnimation;


/**
 * @author kimonik
 * create  2020/4/24  18:30
 */
public class AnimationUtil {

    public static void scaleView(View v, boolean scaleType) {
        if (v == null) {
            return;
        }
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
            v.setElevation(1);
        }
        if (scaleType) {
            ViewCompat.animate(v).setDuration(250).scaleX(1.1f).scaleY(1.1f).start();
        } else {
            ViewCompat.animate(v).setDuration(250).scaleX(1.0f).scaleY(1.0f).start();
        }


//        if (focusFlag) {
//            bacPaintLeft.setColor(bacColorLeftFocused);
//            bacPaintLeft.setShadowLayer(5,3,3, Color.BLACK);
//            borderPaintLeft.setColor(borderColorLeftFocused);
//            bacPaintRight.setColor(bacColorRightNormal);
//            borderPaintRight.setColor(borderColorRightNormal);
//            mLeftContentPaint.setColor(mLeftContentColorFocused);
//            canvas.save();
//            canvas.scale(mScale, mScale,
//                    bacRectFLeft.left + bacRectFLeft.width() / 2, bacRectFLeft.top + bacRectFLeft.height() / 2);
//            canvas.drawRect(bacRectFLeft, bacPaintLeft);
//            canvas.drawRect(bacRectFLeft, borderPaintLeft);
//            canvas.drawText(mLeftContent, mLeftContentStartX, mLeftContentStartY, mLeftContentPaint);
//            canvas.drawBitmap(mRadioSourceFocused, null, mRadioRectF, null);
//
//
//            canvas.restore();
//
//
//        } else {
//            bacPaintLeft.setColor(bacColorLeftNormal);
//            borderPaintLeft.setColor(borderColorLeftNormal);
//            mLeftContentPaint.setColor(mLeftContentColorNormal);
//            bacPaintLeft.clearShadowLayer();
//            canvas.drawRect(bacRectFLeft, bacPaintLeft);
//            canvas.drawRect(bacRectFLeft, borderPaintLeft);
//            canvas.drawText(mLeftContent, mLeftContentStartX, mLeftContentStartY, mLeftContentPaint);
//            canvas.drawBitmap(mRadioSourceNormal, null, mRadioRectF, null);
//
//        }
    }

    public static Bitmap NinePatch2Bitmap(Context context, int resId, int width, int height) {
        Drawable drawable = context.getResources().getDrawable(resId);
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }

    private void animateScale(boolean gainFocus) {
        ValueAnimator valueAnimator;
        if (gainFocus) {
            valueAnimator = ValueAnimator.ofFloat(1.0f, 1.1f);
        } else {
            valueAnimator = ValueAnimator.ofFloat(1.1f, 1.0f);
        }
        valueAnimator.setDuration(150);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float mScale = (float) animation.getAnimatedValue();
//                invalidate();
            }
        });
        valueAnimator.setRepeatCount(0);
        valueAnimator.start();
    }

    private static final long ANIMATION_DURATION = 500;

    public static void shakeViewLR(View view) {
        if (view == null) {
            return;
        }
        TranslateAnimation translateAnimation = new TranslateAnimation(0, 4, 0, 0);
        CycleInterpolator cycleInterpolator = new CycleInterpolator(2);
        translateAnimation.setInterpolator(cycleInterpolator);
        translateAnimation.setDuration(ANIMATION_DURATION);
        view.startAnimation(translateAnimation);

    }

    public static void shakeViewTB(View view) {
        if (view == null) {
            return;
        }
        TranslateAnimation translateAnimation = new TranslateAnimation(0, 0, 0, 4);
        CycleInterpolator cycleInterpolator = new CycleInterpolator(2);
        translateAnimation.setInterpolator(cycleInterpolator);
        translateAnimation.setDuration(ANIMATION_DURATION);
        view.startAnimation(translateAnimation);

    }




}

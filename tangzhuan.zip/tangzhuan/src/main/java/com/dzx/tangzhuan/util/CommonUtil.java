package com.dzx.tangzhuan.util;

import android.app.Activity;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

/**
 * @author dingzhixin
 * create  2020/5/9  16:04
 */
public class CommonUtil {
    public static String getNonNullString(String target, String result) {
        if (TextUtils.isEmpty(target)) {
            if (TextUtils.isEmpty(result)) {
                return "";
            } else {
                return result;
            }
        }
        return target;
    }

    public static void showCustomView(Activity activity, View view) {
        ViewGroup viewGroup = (ViewGroup) activity.getWindow().getDecorView();
//        view.setBackgroundColor(Color.GRAY);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.CENTER;
        view.setLayoutParams(params);
        viewGroup.addView(view);

    }
}

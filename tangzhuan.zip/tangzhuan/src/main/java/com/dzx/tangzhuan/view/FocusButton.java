package com.dzx.tangzhuan.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.dzx.tangzhuan.R;
import com.dzx.tangzhuan.util.AnimationUtil;
import com.dzx.tangzhuan.util.CommonUtil;
import com.dzx.tangzhuan.util.PaintBuilder;


/**
 * @author dingzhixin
 * create  2020/5/11  10:31
 */
public class FocusButton extends View {
    private int mWidth = 300;
    private int mHeight = 84;
    private Drawable mEdgeDrawable;

    private RectF mBacRectF;
    private Paint mBacPaint;
    private int mBacPaintFocusColor;
    private int mBacPaintUnFocusColor;

    private RectF mBorderRectF;
    private Paint mBorderPaint;
    private int mBorderPaintWidth = 1;


    private String mContent = "";
    private Paint mContentPaint;
    private float mContentPaintTextSize = 36;
    private int mContentFocusPaintColor;
    private int mContentUnFocusPaintColor;
    private float mContentStartX;
    private float mContentStartY;

    private boolean mFocusFlag = false;

    public FocusButton(Context context) {
        this(context, null, 0);
    }

    public FocusButton(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FocusButton(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(attrs);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public FocusButton(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(attrs);
    }

    private void init(@Nullable AttributeSet attrs) {
        setFocusable(true);
        setFocusableInTouchMode(true);
        mEdgeDrawable = getResources().getDrawable(R.drawable.bg_btn_focused);
        TypedArray typedArray = getContext().obtainStyledAttributes(attrs, R.styleable.FocusButton);

        //宽高
        mWidth = (int) typedArray.getDimension(R.styleable.FocusButton_focus_button_custom_width, mWidth);
        mHeight = (int) typedArray.getDimension(R.styleable.FocusButton_focus_button_custom_height, mHeight);


        mBacPaintFocusColor = typedArray.getColor(R.styleable.FocusButton_focus_button_bac_paint_focus_color, getResources().getColor(R.color.color_fff1f1f1));
        mBacPaintUnFocusColor = typedArray.getColor(R.styleable.FocusButton_focus_button_bac_paint_un_focus_color, getResources().getColor(R.color.color_33000000));
        int borderPaintColor = typedArray.getColor(R.styleable.FocusButton_focus_button_border_paint_color, getResources().getColor(R.color.color_33f1f1f1));
        mBorderPaintWidth = (int) typedArray.getDimension(R.styleable.FocusButton_focus_button_border_paint_width, mBorderPaintWidth);
        mContent = CommonUtil.getNonNullString(typedArray.getString(R.styleable.FocusButton_focus_button_content), mContent);
        mContentPaintTextSize = typedArray.getDimension(R.styleable.FocusButton_focus_button_content_size, mContentPaintTextSize);
        mContentFocusPaintColor = typedArray.getColor(R.styleable.FocusButton_focus_button_content_focus_text_color, getResources().getColor(R.color.color_ff303a5a));
        mContentUnFocusPaintColor = typedArray.getColor(R.styleable.FocusButton_focus_button_content_un_focus_text_color, getResources().getColor(R.color.color_ccf1f1f1));


        typedArray.recycle();


        mBacRectF = new RectF(0, 0, mWidth, mHeight);
        mBacPaint = new PaintBuilder().setColor(mBacPaintUnFocusColor).build();

        mBorderPaint = new PaintBuilder().setColor(borderPaintColor).setStyle(Paint.Style.STROKE).setStrokeWidth(mBorderPaintWidth).build();
        mBorderRectF = new RectF(mBorderPaintWidth, mBorderPaintWidth, mWidth - mBorderPaintWidth, mHeight - mBorderPaintWidth);

        mContentPaint = new PaintBuilder().setTextSize(mContentPaintTextSize).setColor(mContentFocusPaintColor).build();


    }

    @Override
    protected void onDraw(Canvas canvas) {
        calculateBeforeDraw();
        if (mEdgeDrawable != null && mFocusFlag) {
            mEdgeDrawable.setBounds(-25, -12, getWidth() + 25, getHeight() + 36);
            mEdgeDrawable.draw(canvas);
        }
        canvas.drawRect(mBacRectF, mBacPaint);
        if (!mFocusFlag) {
            canvas.drawRect(mBorderRectF, mBorderPaint);
        }
        canvas.drawText(mContent, mContentStartX, mContentStartY, mContentPaint);
    }

    private void calculateBeforeDraw() {
        if (mFocusFlag) {
            mContentPaint.setColor(mContentFocusPaintColor);
            mBacPaint.setColor(mBacPaintFocusColor);
        } else {
            mBacPaint.setColor(mBacPaintUnFocusColor);
            mContentPaint.setColor(mContentUnFocusPaintColor);
        }
        mContentStartX = PaintBuilder.getCenterDrawX(mWidth, mContentPaint, mContent);
        mContentStartY = PaintBuilder.getCenterDrawY(mHeight, mContentPaint);

    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(mWidth, mHeight);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            requestFocus();
            performClick();
            return true;
        }
        return true;
    }

    @Override
    protected void onFocusChanged(boolean gainFocus, int direction, @Nullable Rect previouslyFocusedRect) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect);
        mFocusFlag = gainFocus;
        invalidate();
        AnimationUtil.scaleView(this, gainFocus);
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    public void setContent(String content) {
        mContent = content;
        invalidate();
    }
}
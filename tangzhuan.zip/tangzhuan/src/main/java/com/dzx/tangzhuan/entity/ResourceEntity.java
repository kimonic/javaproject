package com.dzx.tangzhuan.entity;

import com.chad.library.adapter.base.entity.MultiItemEntity;

/**
 * @author dingzhixin
 * create  2021/2/9  13:19
 */
public class ResourceEntity implements MultiItemEntity {

    private int itemType;
    public static final int TYPE_TANG_ZHUAN_LIST = 1;

    public ResourceEntity() {
        itemType = TYPE_TANG_ZHUAN_LIST;
    }

    public ResourceEntity(int itemType) {
        this.itemType = itemType;
    }

    /**
     * 资源url
     */
    public String resourceUrl;
    /**
     * 资源名称,位置
     */
    public int resourcePosition;

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

    @Override
    public int getItemType() {
        return itemType;
    }
}

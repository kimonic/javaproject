package com.dzx.tangzhuan;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.dzx.tangzhuan.entity.ResourceEntity;
import com.dzx.tangzhuan.util.LUtils;
import com.dzx.tangzhuan.util.M4aDataUtil;
import com.dzx.tangzhuan.util.SharedPreferencesUtils;
import com.dzx.tangzhuan.view.FocusButton;
import com.google.gson.Gson;

import java.util.List;

/**
 * @author dingzhixin.ex
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "MainActivity";

    private MediaPlayer mediaPlayer = new MediaPlayer();
    private FocusButton mFbPlay;
    private FocusButton mFbPause;
    private TextView mTvCurrent;
    private TextView mTvSourceUrl;
    private RecyclerView mRecyclerView;
    private List<ResourceEntity> mDataList;

    private String mCurrentSourceUrl;
    private int mCurrentPosition = 0;

    private static final String LAST_PLAY_INFO = "last_play_info";

    private int mTotalLength = 0;

    /**
     * 监听播放进度的handler
     */
    private Handler mHandler = new Handler(Looper.getMainLooper());
    private Runnable mProgressRunnable = new Runnable() {
        @Override
        public void run() {
            if (mHandler != null) {
                mHandler.removeCallbacksAndMessages(null);
                if (mediaPlayer != null) {
                    if (mediaPlayer.isPlaying()) {
                        mFbPause.setContent(("播放中 " + getMinuteTextByMilliseconds(mediaPlayer.getCurrentPosition())
                                + "/" + getMinuteTextByMilliseconds(mTotalLength)
                        ));
                    } else {
                        mFbPause.setContent(("暂停中 " + getMinuteTextByMilliseconds(mediaPlayer.getCurrentPosition())
                                + "/" + getMinuteTextByMilliseconds(mTotalLength)
                        ));
                    }
                }
                mHandler.postDelayed(this, 1000);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mFbPlay = findViewById(R.id.fb_play);
        mFbPause = findViewById(R.id.fb_pause);
        mTvCurrent = findViewById(R.id.tv_current_listen);
        mRecyclerView = findViewById(R.id.rv_source_list);
        mTvSourceUrl = findViewById(R.id.tv_current_source_url);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        mFbPlay.setOnClickListener(this);
        mFbPause.setOnClickListener(this);
        mTvSourceUrl.setOnClickListener(this);
        mTvCurrent.setOnClickListener(this);
        mDataList = M4aDataUtil.getDataList();
        MainActRvAdapter adapter = new MainActRvAdapter(mDataList);
        mRecyclerView.setAdapter(adapter);


        adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {
                mCurrentPosition = i;
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                }
                TextView textView = view.findViewById(R.id.tv_content);
                mTvCurrent.setText(textView.getText());
                mCurrentSourceUrl = mDataList.get(i).resourceUrl;
                mTvSourceUrl.setText(mCurrentSourceUrl);
            }
        });

        String lastInfo = SharedPreferencesUtils.getString(this, LAST_PLAY_INFO, new Gson().toJson(mDataList.get(mCurrentPosition)));


        try {
            ResourceEntity resourceEntity = new Gson().fromJson(lastInfo, ResourceEntity.class);
            setPlayInfo(resourceEntity);
        } catch (Exception e) {
            LUtils.i(TAG, "DZX   onCreate      = ", LUtils.getErrorMessage(e));
        }

        checkPermission();

    }

    private void copyContentToSystem(String content) {
        // 从API11开始android推荐使用android.content.ClipboardManager
        // 为了兼容低版本我们这里使用旧版的android.text.ClipboardManager，虽然提示deprecated，但不影响使用。
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        // 将文本内容放到系统剪贴板里。
        ClipData clipData = ClipData.newPlainText("sourceUrl", content);
        cm.setPrimaryClip(clipData);
        Toast.makeText(this, "复制成功", Toast.LENGTH_LONG).show();
    }

    private void setPlayInfo(ResourceEntity resourceEntity) {
        if (resourceEntity != null) {
            mCurrentPosition = resourceEntity.resourcePosition - 1;
            mTvCurrent.setText(("第 " + resourceEntity.resourcePosition + " 集"));
            mCurrentSourceUrl = resourceEntity.resourceUrl;
            mTvSourceUrl.setText(mCurrentSourceUrl);
            SharedPreferencesUtils.putString(this, LAST_PLAY_INFO, new Gson().toJson(resourceEntity));

        }
    }

    private void checkPermission() {
        //权限判断，如果没有权限就请求权限
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }

    private void startPlay() {
        try {
            mediaPlayer.reset();
            //指定音频文件路径
            mediaPlayer.setDataSource(mCurrentSourceUrl);
            //初始化播放器MediaPlayer
            mediaPlayer.prepareAsync();
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    Toast.makeText(MainActivity.this, "资源准备完毕,开始播放", Toast.LENGTH_SHORT).show();
                    mTotalLength = mediaPlayer.getDuration();
//                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1) {
                    //设置播放速度
//                        LUtils.i(TAG, "DZX   onCreate 播放速度     = ", mediaPlayer.getPlaybackParams().getSpeed());
//                        mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(1.0f));
//                    }

                    mediaPlayer.start();
                }
            });

            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    Toast.makeText(MainActivity.this, "播放结束,继续下一集", Toast.LENGTH_SHORT).show();
                    if (mCurrentPosition < mDataList.size() - 1) {
                        mCurrentPosition += 1;
                        ResourceEntity resourceEntity = mDataList.get(mCurrentPosition);
                        setPlayInfo(resourceEntity);
                        startPlay();
                    }
                }
            });

            if (mHandler != null) {
                mHandler.post(mProgressRunnable);
            }
        } catch (Exception e) {
            Toast.makeText(MainActivity.this, LUtils.getErrorMessage(e), Toast.LENGTH_LONG).show();
            LUtils.i(TAG, "DZX   startPlay      = ", LUtils.getErrorMessage(e));
        }
    }

    private void setVolume() {
        //调整系统音量
        AudioManager mAudioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        //系统最大音量为15
        int maxVolume = mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT).show();
        LUtils.i(TAG, "DZX   setVolume    maxVolume  = ", maxVolume);
        mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 1, AudioManager.FLAG_SHOW_UI);

    }

    @Override
    public void onClick(View v) {
        if (v == mFbPlay) {
            Toast.makeText(MainActivity.this, "播放点击", Toast.LENGTH_SHORT).show();
            SharedPreferencesUtils.putString(this, LAST_PLAY_INFO, new Gson().toJson(mDataList.get(mCurrentPosition)));
            startPlay();
        } else if (v == mFbPause) {
            if (mediaPlayer.isPlaying()) {
                mFbPause.setContent("已暂停");
                Toast.makeText(MainActivity.this, "播放暂停", Toast.LENGTH_SHORT).show();
                mediaPlayer.pause();
                return;
            }
            if (!mediaPlayer.isPlaying() && mediaPlayer.getCurrentPosition() > 1) {
                Toast.makeText(MainActivity.this, "重新开始播放", Toast.LENGTH_SHORT).show();
                mFbPause.setContent("播放中");
                mediaPlayer.start();
            }
        } else if (mTvSourceUrl == v) {
            copyContentToSystem(mTvSourceUrl.getText().toString());
        } else if (mTvCurrent == v) {
            setVolume();
        } else {
            LUtils.i(TAG, "DZX   onClick  error view = ", v);
        }
    }

    private String getMinuteTextByMilliseconds(int milliseconds) {
        int seconds = milliseconds / 1000;
        int minute = seconds / 60;
        int surplus = seconds - minute * 60;
        StringBuilder builder = new StringBuilder();
        if (minute < 10) {
            builder.append("0").append(minute).append(":");
        } else {
            builder.append(minute).append(":");
        }
        if (surplus < 10) {
            builder.append("0").append(surplus);
        } else {
            builder.append(surplus);
        }
        return builder.toString();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isFinishing()) {
            mHandler.removeCallbacksAndMessages(null);
            mHandler = null;
        }

    }
}
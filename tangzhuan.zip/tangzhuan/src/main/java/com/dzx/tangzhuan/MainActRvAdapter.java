package com.dzx.tangzhuan;

import android.support.annotation.NonNull;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dzx.tangzhuan.entity.ResourceEntity;
import com.dzx.tangzhuan.util.LUtils;

import java.util.List;

/**
 * @author dingzhixin
 * create  2021/2/9  13:22
 */
public class MainActRvAdapter extends BaseMultiItemQuickAdapter<ResourceEntity, BaseViewHolder> {
    public MainActRvAdapter(List<ResourceEntity> data) {
        super(data);
        addItemType(ResourceEntity.TYPE_TANG_ZHUAN_LIST, R.layout.item_rv);
    }

    @Override
    protected void convert(@NonNull BaseViewHolder baseViewHolder, ResourceEntity resourceEntity) {
        if (resourceEntity == null) {
            LUtils.i(TAG, "DZX   convert   entity is null   = ");
            return;
        }

        int type = resourceEntity.getItemType();
        switch (type) {
            case ResourceEntity.TYPE_TANG_ZHUAN_LIST:
                TextView title = baseViewHolder.getView(R.id.tv_content);
                title.setText(("第 " + resourceEntity.resourcePosition + " 集"));
                break;
            default:
                break;
        }

    }
}

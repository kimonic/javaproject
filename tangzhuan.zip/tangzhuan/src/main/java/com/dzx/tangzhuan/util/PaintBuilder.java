package com.dzx.tangzhuan.util;

/**
 * * ================================================
 * <p>
 * name:            PaintBuilder
 * <p>
 * guide:
 * <p>
 * author：          kimonik
 * <p>
 * version：          1.0
 * <p>
 * date：            2019/3/19
 * <p>
 * description：
 * <p>
 * history：
 * <p>
 * ===================================================
 */

import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PathEffect;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.Xfermode;


/**
 * * ================================================
 * name:            PaintBuilder
 * guide:
 * author：          kimonik
 * version：          1.0
 * date：           2018/11/12
 * description：  画笔辅助类
 * notice:
 * introduce:
 * history：
 * ===================================================
 */


public class PaintBuilder {

    private Paint paint;


    public PaintBuilder() {

        paint = new Paint();

        paint.setAntiAlias(true);

    }


    public Paint build() {

        return paint;

    }


    public PaintBuilder setColor(String color) {

        paint.setColor(Color.parseColor(color));

        return this;

    }


    public PaintBuilder setColor(int color) {

        paint.setColor(color);

        return this;

    }


    public PaintBuilder setAntiAlias(boolean antiAlias) {

        paint.setAntiAlias(antiAlias);

        return this;

    }


    public PaintBuilder setAlpha(int alpha) {

        paint.setAlpha(alpha);

        return this;

    }


    public PaintBuilder setStyle(Paint.Style style) {

        paint.setStyle(style);

        return this;

    }


    public PaintBuilder setColorFilter(ColorFilter colorFilter) {

        paint.setColorFilter(colorFilter);

        return this;

    }


    public PaintBuilder setTextSize(float textSize) {

        paint.setTextSize(textSize);

        return this;

    }


    public PaintBuilder setStrokeWidth(float width) {

        paint.setStrokeWidth(width);

        return this;

    }


    //设置粗体

    public PaintBuilder setFakeBoldText(boolean fakeBoldText) {

        paint.setFakeBoldText(fakeBoldText);

        return this;


    }


    //设置字体样式

    public PaintBuilder setTypeface(Typeface fakeBoldText) {

        paint.setTypeface(fakeBoldText);

        return this;

    }

    //设置颜色过滤模式

    public PaintBuilder setXfermode(Xfermode fakeBoldText) {

        paint.setXfermode(fakeBoldText);

        return this;

    }


    //设置直线的端点样式,Paint.Cap.ROUND,端点圆头

    public PaintBuilder setStrokeCap(Paint.Cap cap) {

        paint.setStrokeCap(cap);

        return this;

    }

    //设置绘制path时,path转角处的样式效

    // new CornerPathEffect(2)参数最好为偶数

    public PaintBuilder setPathEffect(PathEffect pathEffect) {

        paint.setPathEffect(pathEffect);

        return this;

    }


    //设置图像效果，使用Shader可以绘制出各种渐变效果

    public PaintBuilder setShader(Shader shader) {


        paint.setShader(shader);

        return this;

    }


    //在图形下面设置阴影层，产生阴影效果，radius为阴影的角度，

    // dx和dy为阴影在x轴和y轴上的距离，color为阴影的颜色

    public PaintBuilder setShadowLayer(float radius, float dx, float dy, int shadowColor) {


        paint.setShadowLayer(radius, dx, dy, shadowColor);

        return this;

    }


    // 设置绘制时各图形的结合方式，如平滑效果等

    public PaintBuilder setStrokeJoin(Paint.Join join) {


        paint.setStrokeJoin(join);

        return this;

    }


    //设置该项为true，将有助于文本在LCD屏幕上的显示效果

    public PaintBuilder setSubpixelText(boolean subpixelText) {


        paint.setSubpixelText(subpixelText);

        return this;

    }


    //设置绘制文字的对齐方向

    public PaintBuilder setTextAlign(Paint.Align align) {


        paint.setTextAlign(align);

        return this;

    }


    //设置绘制文字x轴的缩放比例，可以实现文字的拉伸的效果

    public PaintBuilder setTextScaleX(float scaleX) {


        paint.setTextScaleX(scaleX);

        return this;

    }


    //设置斜体文字，skewX为倾斜弧度

    public PaintBuilder setTextSkewX(float skewX) {


        paint.setTextSkewX(skewX);

        return this;

    }


    //设置带有下划线的文字效果

    public PaintBuilder setUnderlineText(boolean underlineText) {


        paint.setUnderlineText(underlineText);

        return this;

    }


    //设置带有删除线的效果

    public PaintBuilder setStrikeThruText(boolean strikeThruText) {


        paint.setStrikeThruText(strikeThruText);

        return this;

    }


    public static float getAscent(Paint target) {
        return Math.abs(target.ascent());
    }

    public static float getDescent(Paint target) {
        return Math.abs(target.descent());
    }

    public static float getBoundsHeight(Paint target) {
        Rect rect = new Rect();
        target.getTextBounds("你", 0, 1, rect);
        return rect.height();

    }

    public static float getCenterDrawY(float boundsHeight, Paint target) {
        return (boundsHeight + getAscent(target) - getDescent(target)) / 2;
    }

    public static float getCenterDrawX(float boundsWidth, Paint target, String text) {
        return (boundsWidth - target.measureText(text)) / 2;
    }


}
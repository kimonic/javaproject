package com.dzx.tangzhuan.util;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.google.gson.Gson;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Set;


/**
 * Created by kimonik on 2017/5/12 0012.
 * <p>
 * 打印自定义信息
 *
 * C:\Users\Administrator\AppData\Local\Android\Sdk\platform-tools
 */


public class LUtils {


//    private static final boolean  DEBUG=false;

    private static final boolean DEBUG = true;

    private static final int showCount = 3 * 1024;


    /**
     * 显示--类名,方法名,自定义信息
     *
     * @param clz 打印log所在的类
     * @param str 自定义打印的字符串
     *            <p>
     *            mark:Thread.currentThread().getStackTrace()可以获得方法调用顺序
     */

    public static void e(Class clz, String str) {

        if (DEBUG) {

            if (str.length() > showCount) {

                while (str.length() > showCount) {

                    String show = str.substring(0, showCount);

                    str = str.substring(showCount);

                    Log.e(clz.getSimpleName(), "==  " + Thread.currentThread().getStackTrace()[3].getMethodName() + "  =DZX=  " + show + "  =");

                }

                Log.e(clz.getSimpleName(), "==  " + Thread.currentThread().getStackTrace()[3].getMethodName() + "  =DZX=  " + str + "  =");

            } else {

                Log.e(clz.getSimpleName(), "==  " + Thread.currentThread().getStackTrace()[3].getMethodName() + "  =DZX=  " + str + "  =");

            }

        }

    }


    /**
     * 显示--类名,方法名,自定义信息
     *
     * @param clz 打印log所在的类
     * @param str 自定义打印的字符串
     *            <p>
     *            mark:Thread.currentThread().getStackTrace()可以获得方法调用顺序
     */

    public static void d(Class clz, String str) {

        if (DEBUG) {

            if (str.length() > showCount) {

                while (str.length() > showCount) {

                    String show = str.substring(0, showCount);

                    str = str.substring(showCount);

                    Log.d(clz.getSimpleName(), "==  " + Thread.currentThread().getStackTrace()[3].getMethodName() + "  =DZX=  " + show + "  =");

                }

                Log.d(clz.getSimpleName(), "==  " + Thread.currentThread().getStackTrace()[3].getMethodName() + "  =DZX=  " + str + "  =");

            } else {

                Log.d(clz.getSimpleName(), "==  " + Thread.currentThread().getStackTrace()[3].getMethodName() + "  =DZX=  " + str + "  =");

            }

        }

    }

    public static String buildMessage(Object... str) {
        StringBuilder builder = new StringBuilder();

        if (str != null && str.length > 0) {
            for (Object s : str) {
                builder.append(s);
            }
        }

        return builder.toString();

    }

    public static void i(Class clz, Object... objects) {

        if (DEBUG) {

            String str = buildMessage(objects);

            if (str.length() > showCount) {

                while (str.length() > showCount) {

                    String show = str.substring(0, showCount);

                    str = str.substring(showCount);

                    Log.i(clz.getSimpleName(), "==  " + Thread.currentThread().getStackTrace()[3].getMethodName() + "  =DZX=  " + show + "  =");

                }

                Log.i(clz.getSimpleName(), "==  " + Thread.currentThread().getStackTrace()[3].getMethodName() + "  =DZX=  " + str + "  =");

            } else {

                Log.i(clz.getSimpleName(), "==  " + Thread.currentThread().getStackTrace()[3].getMethodName() + "  =DZX=  " + str + "  =");

            }

        }

    }
    public static void i(String clz, Object... objects) {

        if (DEBUG) {

            String str = buildMessage(objects);

            if (str.length() > showCount) {

                while (str.length() > showCount) {

                    String show = str.substring(0, showCount);

                    str = str.substring(showCount);

                    Log.i(clz, "==  " + Thread.currentThread().getStackTrace()[3].getMethodName() + "  =DZX=  " + show + "  =");

                }

                Log.i(clz, "==  " + Thread.currentThread().getStackTrace()[3].getMethodName() + "  =DZX=  " + str + "  =");

            } else {

                Log.i(clz, "==  " + Thread.currentThread().getStackTrace()[3].getMethodName() + "  =DZX=  " + str + "  =");

            }

        }

    }

    public static String getErrorMessage(Throwable throwable) {
        if (throwable == null) {
            return "";
        }
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        throwable.printStackTrace(printWriter);
        return stringWriter.toString();
    }

    public static String getCurrentDateString(Date date) {
        String result;
        SimpleDateFormat simpleDateFormat =
                new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss", Locale.getDefault());
        LUtils.e(LUtils.class, "date = null  " + (date == null));
        if (date == null) {

            result = simpleDateFormat.format(new Date());
        } else {
            result = simpleDateFormat.format(date);
        }
        return result;
    }

    public static void outputBeanContent(Object bean) {
        if (bean == null) {
            return;
        }
        LUtils.e(LUtils.class, "实体数据======      " + new Gson().toJson(bean));
    }


    /**
     * 获取intent中携带的所有参数数据
     */
    public static void getAllExtraInIntent(Intent intent) {
        if (intent == null) {
            return;
        }
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            Set<String> keySet = bundle.keySet();
            for (String keyset : keySet) {
                LUtils.e(LUtils.class, "keyset = " + keyset + ", bundle.get(keyset) = " + bundle.get(keyset));
            }
        }
    }


}

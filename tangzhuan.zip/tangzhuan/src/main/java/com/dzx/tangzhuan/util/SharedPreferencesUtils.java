package com.dzx.tangzhuan.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.text.TextUtils;

/**
 * @author dingzhixin
 * create  2020/12/16  16:42
 */
public class SharedPreferencesUtils {
    private static final String FILE_CONTROL_CONFIG = "file_control_config";

    public static void putBoolean(Context context, String key, boolean value) {
        if (context == null || TextUtils.isEmpty(key)) {
            return;
        }
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putBoolean(key, value);
        editor.apply();
    }


    public static boolean getBoolean(Context context, String key, boolean defaultValue) {
        if (context == null) {
            return defaultValue;
        }
        return getSharedPreferences(context).getBoolean(key, defaultValue);
    }

    public static void putLong(Context context, String key, long value) {
        if (context == null || TextUtils.isEmpty(key)) {
            return;
        }
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putLong(key, value);
        editor.apply();
    }

    public static long getLong(Context context, String key, long defaultValue) {
        if (context == null) {
            return defaultValue;
        }
        return getSharedPreferences(context).getLong(key, defaultValue);
    }

    public static void putInteger(Context context, String key, int value) {
        if (context == null || TextUtils.isEmpty(key)) {
            return;
        }
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putInt(key, value);
        editor.apply();
    }

    public static int getInteger(Context context, String key, int defaultValue) {
        if (context == null) {
            return defaultValue;
        }
        return getSharedPreferences(context).getInt(key, defaultValue);
    }

    public static void putString(Context context, String key, String value) {
        if (context == null || TextUtils.isEmpty(key)) {
            return;
        }
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putString(key, value);
        editor.apply();
    }

    public static String getString(Context context, String key, String defaultValue) {
        if (context == null) {
            return defaultValue;
        }
        return getSharedPreferences(context).getString(key, defaultValue);
    }

    private static SharedPreferences getSharedPreferences(@NonNull Context context) {
        return context.getSharedPreferences(FILE_CONTROL_CONFIG, Context.MODE_PRIVATE);
    }

}
